"""Local PIN verification for voluntary tray controls, not OS tamper protection."""
import hashlib
import hmac
import json
import os
import time
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets

class ControlPIN:
    def __init__(self, base, face=False):
        self.base = Path(base)
        self.face = face
        self.path = self.base / "control-pin.json"

    def exists(self):
        return (self.base / "owner-face.npz").exists() if self.face else self.path.exists()

    @staticmethod
    def digest(pin, salt):
        return hashlib.scrypt(pin.encode(), salt=salt, n=16384, r=8, p=1)

    @staticmethod
    def valid(pin):
        return 6 <= len(pin) <= 128 and pin.isascii() and pin.isdecimal()

    def save(self, pin):
        if not self.valid(pin):
            raise ValueError("Use 6 or more digits.")
        salt = os.urandom(16)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps({"salt":salt.hex(), "digest":self.digest(pin,salt).hex()}))
        temporary.replace(self.path)

    def verify(self, pin):
        try:
            if self.face:
                import numpy as np
                with np.load(self.base / "owner-face.npz", allow_pickle=False) as data:
                    salt, expected = bytes(data["salt"]), bytes(data["digest"])
            else:
                data = json.loads(self.path.read_text())
                salt, expected = bytes.fromhex(data["salt"]), bytes.fromhex(data["digest"])
            return hmac.compare_digest(self.digest(pin,salt), expected)
        except Exception:
            return False

class ProtectedControls:
    def init_controls(self, face=False):
        self.control_pin = ControlPIN(BASE_FOR(self), face)
        self.auth_active = False
        self.auth_failures = 0
        self.auth_retry_after = 0
        if not face and not self.control_pin.exists():
            QtCore.QTimer.singleShot(0, self.setup_control_pin)

    def pin_dialog(self, title, text):
        dialog = QtWidgets.QInputDialog()
        dialog.setWindowTitle("LaptopScreenGuard | " + title)
        dialog.setWindowIcon(self.app.windowIcon())
        dialog.setWindowFlag(QtCore.Qt.WindowType.WindowStaysOnTopHint, True)
        dialog.setLabelText(text)
        dialog.setTextEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        dialog.resize(390, 180)
        dialog.setStyleSheet("QInputDialog {background:#f5f7fb;} QLabel {color:#14273e; font-size:14px;} QLineEdit {padding:10px; border:1px solid #cbd5e1; border-radius:8px;} QPushButton {padding:9px 18px;}")
        return dialog.textValue() if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted else None

    def setup_control_pin(self):
        if self.auth_active:
            return
        self.auth_active = True
        self.input_guard.stop()
        try:
            pin = self.pin_dialog("Set control PIN", "Choose a PIN (6 or more digits) for Pause and Exit.")
            if pin is None:
                self.app.quit()
                return
            if not self.control_pin.valid(pin):
                self.tray.showMessage("LaptopScreenGuard", "Invalid PIN. Restart the app and choose at least six digits.")
                self.app.quit()
                return
            confirmation = self.pin_dialog("Confirm control PIN", "Enter the same PIN again.")
            if pin != confirmation:
                self.tray.showMessage("LaptopScreenGuard", "PIN confirmation did not match. Restart to set up again.")
                self.app.quit()
                return
            self.control_pin.save(pin)
        except Exception:
            self.app.quit()
        finally:
            self.auth_active = False

    def authorize_control(self, action):
        if self.auth_active:
            return False
        # Face Only obtains its control PIN from the first face enrollment.
        if not self.control_pin.exists():
            if self.control_pin.face:
                self.tray.showMessage("LaptopScreenGuard", "Enroll your face and set its PIN first.")
            return False
        if time.monotonic() < self.auth_retry_after:
            self.tray.showMessage("LaptopScreenGuard", "Too many incorrect attempts. Try again in 30 seconds.")
            return False
        self.auth_active = True
        self.input_guard.stop()
        try:
            pin = self.pin_dialog(action, "Enter your app PIN to " + action.lower() + ".")
            if pin is None:
                return False
            if self.control_pin.verify(pin):
                self.auth_failures = 0
                return True
            self.auth_failures += 1
            if self.auth_failures >= 5:
                self.auth_retry_after = time.monotonic() + 30
                self.auth_failures = 0
            self.tray.showMessage("LaptopScreenGuard", "Incorrect PIN. Action canceled.")
            return False
        finally:
            self.auth_active = False

    def request_exit(self):
        if self.authorize_control("Exit LaptopScreenGuard"):
            self.app.quit()

    def set_paused(self, paused):
        if paused == self.paused:
            return
        if not paused or self.authorize_control("Pause monitoring"):
            self.paused = paused
        blocker = QtCore.QSignalBlocker(self.pause_action)
        self.pause_action.setChecked(self.paused)
        del blocker

# The main module passes its installation directory explicitly.
def BASE_FOR(guard):
    return guard.install_base
